/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionmedieval;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author maxim
 */
public class Reino {
    private List<Criatura> criaturas;

    public Reino() {
        this.criaturas = new ArrayList<>();
    }
    
    public void agregarCriatura(Criatura c) throws CriaturaNulaException, CriaturaDuplicadaException {
        if (c == null) {
            throw new CriaturaNulaException("No se puede agregar una criatura nula.");
        }
        for (Criatura existente : criaturas) {
            if (existente.getNombre().equalsIgnoreCase(c.getNombre())
                    && existente.getRegion().equalsIgnoreCase(c.getRegion())) {
                throw new CriaturaDuplicadaException("Ya existe una criatura con nombre '" + c.getNombre() + "' en la region '" + c.getRegion() + "'.");
            }
        }
        criaturas.add(c);
        System.out.println("Criatura agregada: " + c.getNombre() + " (" + c.tipoCriatura() + ") en " + c.getRegion());
    }
    
    public void mostrarCriaturas() {
        if (criaturas.isEmpty()) {
            System.out.println("No hay criaturas registradas.");
            return;
        }
        System.out.println("LISTA DE CRIATURAS");
        for (Criatura c : criaturas) {
            System.out.println(c.toString());
        }
    }
    
    public void entrenarCriaturas() throws AccionNoPermitidaException {
        if (criaturas.isEmpty()) {
            System.out.println("No hay criaturas para entrenar.");
            return;
        }
        System.out.println("ENTRENAMINTO DE CRIATURAS");
        for (Criatura c : criaturas) {
            if (c instanceof Entrenable) {
                ((Entrenable) c).entrenar();
            } else {
                throw new AccionNoPermitidaException("La criatura '" + c.getNombre() + "' (tipo " + c.tipoCriatura() + ") no puede ser entrenada.");
            }
        }
    }
    
    public void regenerarEnergias() throws AccionNoPermitidaException {
        if (criaturas.isEmpty()) {
            System.out.println("No hay criaturas para regenerar.");
            return;
        }
        System.out.println("REGENERACION DE ENERGIA");
        for (Criatura c : criaturas) {
            if (c instanceof Regenerable) {
                ((Regenerable) c).regenerarEnergia();
            } else {
                throw new AccionNoPermitidaException("La criatura '" + c.getNombre() + "' (tipo " + c.tipoCriatura() + ") no puede regenerar energia.");
            }
        }
    }
    
    public List<Criatura> filtrarPorNivelDeMagia(NivelDeMagia nivel) {
        List<Criatura> resultado = new ArrayList<>();
        System.out.println("CRIATURAS CON NIVEL DE MAGIA " + nivel);
        for (Criatura c : criaturas) {
            if (c.getNivelMagia()== nivel) {
                resultado.add(c);
                System.out.println(c.toString());
            }
        }
        if (resultado.isEmpty()) {
            System.out.println("No se encontraron criaturas con ese nivel de magia.");
        }
        return resultado;
    }
    
    public void filtrarPorTipoDeCriatura(String tipo) {
    if (tipo == null) {
        System.out.println("Tipo de criatura inválido.");
        return;
    }
    
    String buscado = tipo.toLowerCase();
    boolean encontrado = false;

    System.out.println("CRIATURAS DE TIPO " + tipo);

    for (Criatura c : criaturas) {
        String actual = c.tipoCriatura().toLowerCase();

        if (actual.equals(buscado)) {
            System.out.println(c);
            encontrado = true;
        }
    }

    if (!encontrado) {
        System.out.println("No se encontraron criaturas del tipo solicitado.");
    }
}

}
