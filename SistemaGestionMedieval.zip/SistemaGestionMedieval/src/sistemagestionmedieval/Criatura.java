/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionmedieval;

/**
 *
 * @author maxim
 */
public abstract class Criatura {
    private String nombre;
    private String region;
    private NivelDeMagia nivelMagia;

    public Criatura(String nombre, String region, NivelDeMagia nivelMagia) {
        this.nombre = nombre;
        this.region = region;
        this.nivelMagia = nivelMagia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRegion() {
        return region;
    }

    public NivelDeMagia getNivelMagia() {
        return nivelMagia;
    }
    
   public String tipoCriatura() {
        return this.getClass().getSimpleName();
    }
    
    protected abstract String detallesEspecificos();

    @Override
    public String toString() {
        return String.format("[%s] Nombre: %s | Region: %s | Nivel: %s | %s",
                tipoCriatura(), nombre, region, nivelMagia, detallesEspecificos());
    }
    
    
    
}
