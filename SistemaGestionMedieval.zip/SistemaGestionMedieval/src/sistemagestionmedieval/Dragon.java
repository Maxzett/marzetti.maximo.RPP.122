/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionmedieval;

/**
 *
 * @author maxim
 */
public class Dragon extends Criatura implements Entrenable{
    private double potenciaDeFuego;

    public Dragon(String nombre, String region, NivelDeMagia nivelMagia, double potenciaDeFuego) {
        super(nombre, region, nivelMagia);
        this.potenciaDeFuego = potenciaDeFuego;
    }

    public double getPotenciaDeFuego() {
        return potenciaDeFuego;
    }
    
    @Override
    protected String detallesEspecificos() {
        return "PotenciaFuego: " + potenciaDeFuego;
    }

    @Override
    public void entrenar() {
        System.out.println("Entrenando dragon '" + getNombre() + "'. Aumenta potencia de fuego.");
    }
}
