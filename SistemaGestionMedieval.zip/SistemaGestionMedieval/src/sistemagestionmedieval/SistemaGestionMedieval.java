/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestionmedieval;

/**
 *
 * @author maxim
 */
public class SistemaGestionMedieval {
    public static void main(String[] args) throws Exception {
        
        Reino reino = new Reino();
        
        try{
            Criatura c1= new Dragon("Fafnir", "Montanas", NivelDeMagia.MEDIA, 5);
            Criatura c2= new Elfo("Ogro", "Pantano", NivelDeMagia.BAJA, "telepatia");
            Criatura c3= new Dragon("Dragonnn", "Montanas", NivelDeMagia.MEDIA, 5);
            Criatura c4= new Golem("Golemm", "Montanas", NivelDeMagia.BAJA, 6);
            Criatura c5= new Golem("Gol", "Montanas", NivelDeMagia.MEDIA, 15);
            
            reino.agregarCriatura(c1);
            reino.agregarCriatura(c2);
            reino.agregarCriatura(c3);
            reino.agregarCriatura(c4);
            reino.agregarCriatura(c5);
            
        }catch(CriaturaDuplicadaException | CriaturaNulaException | AccionNoPermitidaException e){
            System.out.println("Excepcion al agregar: " + e.getMessage());
        }
        
        reino.mostrarCriaturas();
        
        reino.entrenarCriaturas();
        reino.regenerarEnergias();
        
        reino.filtrarPorNivelDeMagia(NivelDeMagia.BAJA);
        reino.filtrarPorTipoDeCriatura("dragon");
                
        
    }
    
}
