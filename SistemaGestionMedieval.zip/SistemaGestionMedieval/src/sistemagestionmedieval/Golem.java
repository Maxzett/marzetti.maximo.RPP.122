/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionmedieval;

/**
 *
 * @author maxim
 */
public class Golem extends Criatura implements Regenerable{
    private int peso;

    public Golem(String nombre, String region, NivelDeMagia nivel, int pesoToneladas) throws Exception {
        super(nombre, region, nivel);

        if (pesoToneladas < 1 || pesoToneladas > 20) {
            throw new Exception("El peso del golem debe estar entre 1 y 20 toneladas. Valor ingresado: " + pesoToneladas);
        }

        this.peso = peso;
    }

    public int getPeso() {
        return peso;
    }
    
    @Override
    public String detallesEspecificos() {
        return "Peso(ton): " + peso;
    }
    
    @Override
    public void regenerarEnergia() {
        System.out.println("Regenerando energía del golem '" + getNombre());
    }
    
}
