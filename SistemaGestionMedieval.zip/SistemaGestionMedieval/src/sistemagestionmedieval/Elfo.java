/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionmedieval;

/**
 *
 * @author maxim
 */
public class Elfo extends Criatura implements Entrenable, Regenerable{
    private String habilidadEspecial;

    public Elfo(String nombre, String region, NivelDeMagia nivelMagia, String habilidadEspecial) {
        super(nombre, region, nivelMagia);
        this.habilidadEspecial = habilidadEspecial;
    }

    public String getHabilidadEspecial() {
        return habilidadEspecial;
    }
    
    @Override
    protected String detallesEspecificos() {
        return "Habilidad: " + habilidadEspecial;
    }

    @Override
    public void entrenar() {
        System.out.println("Entrenando elfo '" + getNombre() + "'. Mejora habilidad: " + habilidadEspecial);
    }

    @Override
    public void regenerarEnergia() {
        System.out.println("Regenerando energia de Elfo '" + getNombre() + "'. Energia restaurada.");
    }
    
}
