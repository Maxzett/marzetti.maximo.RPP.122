/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package sistemagestionmedieval;

/**
 *
 * @author maxim
 */
public class CriaturaDuplicadaException extends Exception {

    private static final String MESSAGE = "ERROR: esta criatura ya existe.";
    public CriaturaDuplicadaException() {
        this(MESSAGE);
    }
    
    public CriaturaDuplicadaException(String msg) {
        super(msg);
    }
}
